
require("prototypes.category")

require("prototypes.entity.poles")

require("prototypes.item.poles")

require("prototypes.recipe.poles")

require("prototypes.technology.poles")
