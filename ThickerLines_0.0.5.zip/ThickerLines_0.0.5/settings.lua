data:extend({
	{
		name = 'thicker-lines-copper',
		setting_type = 'startup',
		type = 'bool-setting',
		default_value = true,
		order = "a",
	}, {
		name = 'thicker-lines-circuit',
		setting_type = 'startup',
		type = 'bool-setting',
		default_value = true,
		order = "b",
	}, {
		name = 'thicker-lines-shadow',
		setting_type = 'startup',
		type = 'bool-setting',
		default_value = true,
		order = "c",
	},
})
