require("compatibility-scripts/data-final-fixes/IndustrialRevolution")
