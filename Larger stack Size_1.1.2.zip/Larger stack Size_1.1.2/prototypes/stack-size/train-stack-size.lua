
local train_stack_size = settings.startup["train-stack-size"].value

if train_stack_size == ("larger-stack-size") then

	data.raw.item["train-stop"].stack_size = 20
	data.raw.item["rail-signal"].stack_size = 100
	data.raw.item["rail-chain-signal"].stack_size = 100
	data.raw["rail-planner"]["rail"].stack_size = 1000
	
	data.raw["item-with-entity-data"]["locomotive"].stack_size = 10
	data.raw["item-with-entity-data"]["cargo-wagon"].stack_size = 10
	data.raw["item-with-entity-data"]["fluid-wagon"].stack_size = 10
	data.raw["item-with-entity-data"]["artillery-wagon"].stack_size = 10
	
end
