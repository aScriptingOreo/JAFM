
local utility_stack_size = settings.startup["utility-stack-size"].value

if utility_stack_size == ("larger-stack-size") then

	for _, item in pairs(data.raw.item) do
		if string.match (item.name, "transport") then item.stack_size = 300 end
		if string.match (item.name, "underground") then item.stack_size = 100 end
		if string.match (item.name, "splitter") then item.stack_size = 100 end
		if string.match (item.name, "pipe") then item.stack_size = 200 end
	end
	data.raw.item["pump"].stack_size = 100
	
end