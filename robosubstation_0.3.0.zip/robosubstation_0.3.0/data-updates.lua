table.insert(data.raw.technology["electric-energy-distribution-2"].effects,
	{ type = "unlock-recipe", recipe = "robosubstation" }
)
