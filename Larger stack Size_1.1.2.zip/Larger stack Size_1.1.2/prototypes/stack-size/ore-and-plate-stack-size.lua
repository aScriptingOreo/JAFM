
local ore_plate_stack_size = settings.startup["ore-and-plate-stack-size"].value

if ore_plate_stack_size == ("larger-stack-size") then

	for _, item in pairs(data.raw.item) do
		if string.match (item.name, "-ore") then item.stack_size = 200 end
		if string.match (item.name, "plate") then item.stack_size = 200 end
	end
	data.raw.item["coal"].stack_size = 200
	data.raw.item["stone"].stack_size = 200
	
end