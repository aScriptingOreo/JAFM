data:extend({
  {
    type = "int-setting",
    name = "robosubstation-logistics-radius",
    order = "a",
    setting_type = "startup",
    default_value = 9,
    minimum_value = 0,
    maximum_value = 100,
  },
  {
    type = "int-setting",
    name = "robosubstation-construction-radius",
    order = "b",
    setting_type = "startup",
    default_value = 20,
    minimum_value = 0,
    maximum_value = 100,
  },
  {
    type = "bool-setting",
    name = "robosubstation-compat-LightedPolesPlus",
    order = "a",
    setting_type = "runtime-global",
    default_value = true,
  },
})
