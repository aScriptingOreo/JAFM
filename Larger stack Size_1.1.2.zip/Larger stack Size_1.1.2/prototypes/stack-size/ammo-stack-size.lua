
local ammo_stack_size = settings.startup["ammo-stack-size"].value

if ammo_stack_size == ("larger-stack-size") then

	for _, item in pairs(data.raw.ammo) do
		if string.match (item.name, "magazine") then item.stack_size = 500 end
	end
	data.raw.ammo["artillery-shell"].stack_size = 10
end