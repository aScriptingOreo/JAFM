data.raw["furnace"]["electric-incinerator"].crafting_speed = settings.startup["ptx0-flarestack-speed"].value
