data:extend(
{
  {
    type = "recipe",
    name = "advanced-accumulator",
    energy_required = 25,
    enabled = "false",
    ingredients =
    {
      {"accumulator", 10},
      {"iron-plate", 25},
      {"battery", 10}
    },
    result = "advanced-accumulator"
  }
}
)
