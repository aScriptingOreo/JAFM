data:extend(
{
	{
		type = "double-setting",
		name = "at_dmg_multiplier",
		order = "a1",
		setting_type = "startup",
		minimum_value = 0.5,
		maximum_value = 100,
		default_value = 1
	},
	{
		type = "double-setting",
		name = "at_atkspd_multiplier",
		order = "a1",
		setting_type = "startup",
		minimum_value = 0.5,
		maximum_value = 100,
		default_value = 1
	}--[[,
	{
		type = "double-setting",
		name = "at_add_tech_bonuses",
		order = "a1",
		setting_type = "startup",
		minimum_value = 1.1,
		maximum_value = 100,
		default_value = 2
	}]]
})
