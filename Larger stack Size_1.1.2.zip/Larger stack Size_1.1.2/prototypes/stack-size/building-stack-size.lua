
local building_stack_size = settings.startup["building-stack-size"].value

if building_stack_size == ("larger-stack-size") then

	for _, item in pairs(data.raw.item) do
		if string.match (item.name, "drill") then item.stack_size = 100 end
	end
	data.raw.item["pumpjack"].stack_size = 100
end