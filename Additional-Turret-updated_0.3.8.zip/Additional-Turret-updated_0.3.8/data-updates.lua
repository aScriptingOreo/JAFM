local exclude_string_list = {"fish", "capture", "train", "goto", "remote", "cliff", "nuclear", "nuke", "hatch", "rampant", "lemon"}

local is_active_capsule = function(capsule)
	--print logs of failure points for debugging are commented out
	local is_true = false
	--check it exists first
	if not capsule then
		--not found
		--log("no capsule")
		goto skipto
	end
	--check if on the exclude list
	for _, str in pairs(exclude_string_list) do
		if string.find(capsule.name, str) then
			is_true = false
			--log("failure str:"..str)
			goto skipto
		end
	end
	--check it has an action
	--dig deep into the table, checking each step exists before moving on
	
	if capsule.capsule_action then
		if capsule.capsule_action.attack_parameters then
			if capsule.capsule_action.attack_parameters.ammo_type then
				if capsule.capsule_action.attack_parameters.ammo_type.action then
					if capsule.capsule_action.attack_parameters.ammo_type.action[1] then --new method
						if capsule.capsule_action.attack_parameters.ammo_type.action[1].action_delivery then
							if capsule.capsule_action.attack_parameters.ammo_type.action[1].action_delivery.projectile then
								is_true = true
							else
								--log("capsule.capsule_action.attack_parameters.ammo_type.action[1].action_delivery")
								--log(serpent.block(capsule.capsule_action.attack_parameters.ammo_type.action[1].action_delivery))
							end
						else
							--log("capsule.capsule_action.attack_parameters.ammo_type.action[1]")
							--log(serpent.block(capsule.capsule_action.attack_parameters.ammo_type.action[1]))
						end
					elseif capsule.capsule_action.attack_parameters.ammo_type.action.action_delivery then --old method
						if capsule.capsule_action.attack_parameters.ammo_type.action.action_delivery.projectile then
							is_true = true
						else
							--log("capsule.capsule_action.attack_parameters.ammo_type.action.action_delivery")
							--log(serpent.block(capsule.capsule_action.attack_parameters.ammo_type.action.action_delivery))
						end
					else
						--log("capsule.capsule_action.attack_parameters.ammo_type.action")
						--log(serpent.block(capsule.capsule_action.attack_parameters.ammo_type.action))
					end
				else
					--log("capsule.capsule_action.attack_parameters.ammo_type")
					--log(serpent.block(capsule.capsule_action.attack_parameters.ammo_type))
				end
			else
				--log("capsule.capsule_action.attack_parameters")
				--log(serpent.block(capsule.capsule_action.attack_parameters))
			end
		else
			--log("capsule.capsule_action")
			--log(serpent.block(capsule.capsule_action))
		end
	else
		--log(serpent.block(capsule))
	end
	::skipto::
	return is_true
end

for _, capsule in pairs(data.raw.capsule) do
	if is_active_capsule(capsule) then
		if string.find(capsule.name, "grenade") or string.find(capsule.name, "capsule") then
			if capsule.icon then
				data:extend({
					{
						type = "ammo",
						name = "at_" .. capsule.name,
						localised_name = {"item-name.at_" .. capsule.name},
						icon = capsule.icon,
						icon_size = capsule.icon_size or 32,
						flags = {"hidden"},
						ammo_type = {
							category = "capsule",
							action = {
								type = "direct",
								action_delivery = {
									type = "projectile",
									projectile = capsule.name,
									starting_speed = 1
								}
							}
						},
						subgroup = "capsule",
						order = capsule.order,
						magazine_size = 1,
						stack_size = capsule.stack_size
					},
					--{type="recipe",name="at_"..capsule.name,ingredients={{capsule.name,1}}, results={{"at_"..capsule.name,1}}, energy_required=0.5},--this is just a testing line
				})
			elseif capsule.icons then
				data:extend({
					{
						type = "ammo",
						name = "at_" .. capsule.name,
						localised_name = {"item-name.at_" .. capsule.name},
						icons = capsule.icons,
						flags = {"hidden"},
						ammo_type = {
							category = "capsule",
							action = {
								type = "direct",
								action_delivery = {
									type = "projectile",
									projectile = capsule.name,
									starting_speed = 1
								}
							}
						},
						subgroup = "capsule",
						order = capsule.order,
						magazine_size = 1,
						stack_size = capsule.stack_size
					},
					--{type="recipe",name="at_"..capsule.name,ingredients={{capsule.name,1}}, results={{"at_"..capsule.name,1}}, energy_required=0.5},--this is just a testing line
				})
			end
		end
	end
end
