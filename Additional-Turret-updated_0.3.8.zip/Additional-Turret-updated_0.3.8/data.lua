require("prototypes.acid")
require("prototypes.others")
-- require("prototypes.wall")

require("prototypes.turret-artillery")
require("prototypes.turret-cannon")
require("prototypes.turret-laser")
require("prototypes.turret-laser-capsule")
require("prototypes.turret-rocket")
require("prototypes.turret-cannon-rocket")

require("prototypes.ammo-item")
require("prototypes.ammo-projectiles")
require("prototypes.ammo-recipe")

require("prototypes.technology-ammo")
require("prototypes.technology-item")
require("prototypes.technology-turret")
require("prototypes.technology-turret-upgrade")
-- require("prototypes.technology-wall")
------------------------------
local default_gui = data.raw["gui-style"].default

--
-- @see https://forums.factorio.com/viewtopic.php?f=28&t=24292
--

function sprite(filename, size, scale, shift, position)
  return {
    filename = filename,
    priority = "extra-high-no-scale",
    align = "center",
    width = size,
    height = size,
    scale = scale,
    shift = shift,
    x = position.x,
    y = position.y
  }
end

function spriteIcon(filename, size, scale, shift, position)
  return {
    type = "sprite",
    sprite = sprite(filename, size, scale, shift, position)
  }
end

function monolithIcon(filename, size, scale, shift, position, border, stretch)
  return {
    filename = filename,
    priority = "extra-high-no-scale",
    align = "center",
    size = size,
    scale = scale,
    shift = shift,
    position = position,
    border = border.top
  }
end

function compositionIcon(filename, corner_size, position)
  return {
    type = "composition",
    filename = filename,
    priority = "extra-high-no-scale",
    corner_size = corner_size,
    position = position
  }
end

--
-- @see https://forums.factorio.com/viewtopic.php?f=28&t=24294
--
function layeredIcon (filename, size, scale, shift, position)
  return {
    type = "layered",
    layers = {
      { -- the border and background are a composition
        type = "composition",
        filename = "__core__/graphics/gui-new.png",
        corner_size = {3, 3},
        position = {0, 0}
      },
      {
        type = "monolith",
        monolith_image = sprite(filename, size, scale, shift, position)
      }
    }
  }
end

-------------------------------------------------------------------------------
-- Style of default
--
-- @field [parent=#Textfield] default
default_gui["at_textfield"] = {
  type = "textbox_style",
  parent = "search_textfield_with_fixed_width",
  minimal_width = 70,
  maximal_width = 70
}
data:extend({
{
	type = "custom-input",
	name = "at_button_opener",
	key_sequence = "CONTROL + Q",
	consuming = "none"
}
})
-------------------------------------------------------------------------------
-- Style Textbox
--
-- @type Textbox
--

-------------------------------------------------------------------------------
-- Style of default
--
-- @field [parent=#Textbox] default
default_gui["at_textbox_default"] = {
  type = "textbox_style",
  parent = "textbox",
  minimal_width = 300,
  maximal_width = 300,
  minimal_height = 300,
  maximal_height = 200
}


-------------------------------------------------------------------------------
-- Style Button
--
-- @type Button
--

-------------------------------------------------------------------------------
-- Style of default
--
-- @field [parent=#Button] default

local corner_size = {3, 3}
default_gui["at_button_default"] = {
  type = "button_style",
  font = "at_font_normal",
  default_font_color={r=1, g=1, b=1},
  align = "center",
  top_padding = 0,
  right_padding = 2,
  bottom_padding = 0,
  left_padding = 2,
  height = 28,
  default_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {0, 17}),
  hovered_font_color={r=0, g=0, b=0},
  hovered_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {34, 17}),
  clicked_font_color={r=1, g=1, b=1},
  clicked_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {51, 17}),
  disabled_font_color={r=0.5, g=0.5, b=0.5},
  disabled_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {17, 17}),
  pie_progress_color = {r=1, g=1, b=1}
}

-------------------------------------------------------------------------------
-- Style of default
--
-- @field [parent=#Button] selected

default_gui["at_button_selected"] = {
  type = "button_style",
  font = "at_font_normal",
  default_font_color={r=1, g=1, b=1},
  align = "center",
  top_padding = 0,
  right_padding = 2,
  bottom_padding = 0,
  left_padding = 2,
  height = 28,
  default_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {0, 17}),
  hovered_font_color={r=1, g=1, b=1},
  hovered_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {34, 17}),
  clicked_font_color={r=1, g=1, b=1},
  clicked_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {51, 17}),
  disabled_font_color={r=0.5, g=0.5, b=0.5},
  disabled_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {17, 17}),
  pie_progress_color = {r=1, g=1, b=1}
}

-------------------------------------------------------------------------------
-- Style of button
--
-- @field [parent=#Button] favicon

local icon_corner_size = 1
default_gui["at_icon"] = {
  type = "button_style",
  parent = "at_button_default",
  width = 32,
  height = 32,
  scalable = false,
  default_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=0}, {top=0,right=0,bottom=0,left=0}, true),
  hovered_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=36}, {top=0,right=0,bottom=0,left=0}, true),
  clicked_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=72}, {top=0,right=0,bottom=0,left=0}, true),
  disabled_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=0}, {top=0,right=0,bottom=0,left=0}, true)
}

-------------------------------------------------------------------------------
-- Style of button
--
-- @field [parent=#Button] icon_default

default_gui["at_button_icon_default"] = {
  type = "button_style",
  parent = "at_button_default",
  default_graphical_set = compositionIcon("__core__/graphics/gui-new.png", {icon_corner_size, icon_corner_size}, {3 - icon_corner_size, 3 - icon_corner_size}),
  hovered_graphical_set = compositionIcon("__core__/graphics/gui-new.png", {icon_corner_size, icon_corner_size}, {3 - icon_corner_size, 11 - icon_corner_size}),
  clicked_graphical_set = compositionIcon("__core__/graphics/gui-new.png", {icon_corner_size, icon_corner_size}, {3 - icon_corner_size, 43 - icon_corner_size}),
  disabled_graphical_set = compositionIcon("__core__/graphics/gui-new.png", {icon_corner_size, icon_corner_size}, {3 - icon_corner_size, 19 - icon_corner_size}),
}
---------------------------------------
-- Style of selection
--
--
default_gui["at_select_style"]={
	type = "button_style",
	parent = "at_button_default",
	width = 33,
	height = 33,
	scalable = false,
	default_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {0, 17}),
  hovered_font_color={r=1, g=1, b=1},
  hovered_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {34, 17}),
  clicked_font_color={r=1, g=1, b=1},
  clicked_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {51, 17}),
  disabled_font_color={r=0.5, g=0.5, b=0.5},
  disabled_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {17, 17}),
  pie_progress_color = {r=1, g=1, b=1}
}
default_gui["at_selected_style"]={
	type = "button_style",
	parent = "at_button_default",
	width = 33,
	height = 33,
	scalable = false,
	default_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {0, 17}),
  hovered_font_color={r=1, g=1, b=1},
  hovered_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {34, 17}),
  clicked_font_color={r=1, g=1, b=1},
  clicked_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {51, 17}),
  disabled_font_color={r=0.5, g=0.5, b=0.5},
  disabled_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {17, 17}),
  pie_progress_color = {r=1, g=1, b=1}
}
default_gui["at_selected_style"]={
	type = "button_style",
	parent = "at_button_default",
	width = 33,
	height = 33,
	scalable = false,
	default_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {0, 17}),
  hovered_font_color={r=1, g=1, b=1},
  hovered_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {34, 17}),
  clicked_font_color={r=1, g=1, b=1},
  clicked_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {51, 17}),
  disabled_font_color={r=0.5, g=0.5, b=0.5},
  disabled_graphical_set = compositionIcon("__core__/graphics/gui-new.png", corner_size, {17, 17}),
  pie_progress_color = {r=1, g=1, b=1}
}
default_gui["at_setting_button_style"]={
    type = "button_style",
    parent = "at_button_default",
    width = 32,
    height = 32,
    scalable = false,
		default_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=0}, {top=0,right=0,bottom=0,left=0}, true),
	  hovered_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=36}, {top=0,right=0,bottom=0,left=0}, true),
	  clicked_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=72}, {top=0,right=0,bottom=0,left=0}, true),
	  disabled_graphical_set = monolithIcon("__Additional-Turret-updated__/graphics/button.png", 36, 1, {0,0}, {x=0,y=0}, {top=0,right=0,bottom=0,left=0}, true)
	}
data:extend(
{
  {
    type = "font",
    name = "at_font_normal",
    from = "default",
    size = 12
}})

function number_gen(input)
return
{
	type = "sprite",
	name = input.name,
	filename = "__Additional-Turret-updated__/graphics/number.png",
	priority = "extra-high-no-scale",
	width = 16,
	height = 25,
	x = input.x,
	y = 0,
}
end
for i = 0, 10 do
	data:extend({ number_gen{name = "number_"..i, x = 16*i} })
end
