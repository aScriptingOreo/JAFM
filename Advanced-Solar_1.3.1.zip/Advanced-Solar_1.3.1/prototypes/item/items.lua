data:extend(
{
  {
    type = "item",
    name = "advanced-accumulator",
    icon = "__Advanced-Solar__/graphics/advanced-accumulator/advanced-accumulator-icon.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "energy",
    order = "e[accumulator]-b[advanced-accumulator]",
    place_result = "advanced-accumulator",
    stack_size = 50
  },
  {
    type = "item",
    name = "advanced-solar",
    icon = "__Advanced-Solar__/graphics/advanced-solar/advanced-solar-icon.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "energy",
    order = "d[solar-panel]-b[advanced-solar]",
    place_result = "advanced-solar",
    stack_size = 50
  },
  {
    type = "item",
    name = "elite-accumulator",
    icon = "__Advanced-Solar__/graphics/elite-accumulator/elite-accumulator-icon.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "energy",
    order = "e[accumulator]-c[elite-accumulator]",
    place_result = "elite-accumulator",
    stack_size = 50
  },
  {
    type = "item",
    name = "elite-solar",
    icon = "__Advanced-Solar__/graphics/elite-solar/elite-solar-icon.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "energy",
    order = "d[solar-panel]-c[elite-solar]",
    place_result = "elite-solar",
    stack_size = 50
  }
}
)
