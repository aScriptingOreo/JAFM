data:extend({
    {
        type = "bool-setting",
        name = "TrainSkipFulfilledStation-CheckCircuitConditions",
        setting_type = "runtime-global",
        default_value = false
    },
    {
        type = "bool-setting",
        name = "TrainSkipFulfilledStation-SkipEmpty",
        setting_type = "runtime-global",
        default_value = false
    }
})