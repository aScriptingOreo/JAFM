--[[function damage_upgrade(inputs) -- damage_upgrade{name, icon, effects, prerequisites, ingredients, time, max_level, order}
return
{
	type = "technology",
	name = inputs.name,
	icon_size = 128,
	icon = inputs.icon,
	effects = inputs.effects,
	prerequisites = inputs.prerequisites,
	unit =
	{
		count_formula = "100*L",
		ingredients = inputs.ingredients,
		time = inputs.time
	},
	upgrade = true,
	max_level = inputs.max_level,
	order = inputs.order,
}
end

--------------

local name_list = {"turret-mk1-damage-", "turret-mk2-damage-", "turret-mk3-damage-", "thrower-turret-damage-"}
local icon_list = {
	"__Additional-Turret-updated__/graphics/technology/turret-mk1-damage.png",
	"__Additional-Turret-updated__/graphics/technology/turret-mk2-damage.png",
	"__Additional-Turret-updated__/graphics/technology/turret-mk3-damage.png",
	"__Additional-Turret-updated__/graphics/technology/acid-thrower-damage.png"
}
local effects_list = {
					{{
							type = "turret-attack",
							turret_id = "at-cannon-turret-mk1",
							modifier = 0.1,
						},
						{
							type = "turret-attack",
							turret_id = "at-rocket-turret-mk1",
							modifier = 0.1,
					}},
					{{
							type = "turret-attack",
							turret_id = "at-cannon-turret-mk2",
							modifier = 0.1,
						},
						{
							type = "turret-attack",
							turret_id = "at-rocket-turret-mk2",
							modifier = 0.1,
					}},
					{{
							type = "turret-attack",
							turret_id = "at_CR_s1",
							modifier = 0.1,
						},
						{
							type = "turret-attack",
							turret_id = "at_CR_s2",
							modifier = 0.1,
					}},
					{
						-- {
							-- type = "ammo-damage",
							-- ammo_category = "acid-thrower-ammo",
							-- modifier = 0.2
						-- },
						{
							type = "turret-attack",
							turret_id = "at-acidthrower-turret",
							modifier = 0.1,
					}},

				}
local prerequisites_list = {"turret-mk1-unlock", "turret-mk2-unlock", "turret-mk3-unlock", "acid-thrower"}
local ingredients_list = {{"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"military-science-pack", 1}, {"utility-science-pack", 1}, {"space-science-pack", 1}}
local time_list = {10, 20, 30, 60, 120}
local max_level_list = {"10", "20", "40", "80", "infinite"}
local next_level = {"11", "21", "41", "81"}
local order_list = {"e-o-q-a", "e-o-q-c", "e-o-q-e", "e-o-p-a"}
for i = 1, 4 do
	data:extend({
		damage_upgrade{name = name_list[i].."1", icon = icon_list[i],
						effects = effects_list[i],
						prerequisites = {prerequisites_list[i]},
						ingredients = {ingredients_list[1], ingredients_list[2]},
						time = time_list[1], max_level = max_level_list[1], order = order_list[i]},
		damage_upgrade{name = name_list[i]..next_level[1], icon = icon_list[i],
						effects = effects_list[i],
						prerequisites = {name_list[i].."1"},
						ingredients = {ingredients_list[1], ingredients_list[2], ingredients_list[3]},
						time = time_list[2], max_level = max_level_list[2], order = order_list[i]},
		damage_upgrade{name = name_list[i]..next_level[2], icon = icon_list[i],
						effects = effects_list[i],
						prerequisites = {name_list[i]..next_level[1]},
						ingredients = {ingredients_list[1], ingredients_list[2], ingredients_list[3], ingredients_list[4]},
						time = time_list[3], max_level = max_level_list[3], order = order_list[i]},
		damage_upgrade{name = name_list[i]..next_level[3], icon = icon_list[i],
						effects = effects_list[i],
						prerequisites = {name_list[i]..next_level[2]},
						ingredients = {ingredients_list[1], ingredients_list[2], ingredients_list[3], ingredients_list[4], ingredients_list[5]},
						time = time_list[4], max_level = max_level_list[4], order = order_list[i]},
		damage_upgrade{name = name_list[i]..next_level[4], icon = icon_list[i],
						effects = effects_list[i],
						prerequisites = {name_list[i]..next_level[3]},
						ingredients = {ingredients_list[1], ingredients_list[2], ingredients_list[3], ingredients_list[4], ingredients_list[5], ingredients_list[6]},
						time = time_list[5], max_level = max_level_list[5], order = order_list[i]},
	})
end]]
-- CANNON TURRET DAMAGE BOOST, may need balancing
table.insert(data.raw.technology["physical-projectile-damage-3"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-3"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-4"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-4"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-5"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-5"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-6"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-6"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["physical-projectile-damage-7"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk1",modifier = 0.2})
table.insert(data.raw.technology["physical-projectile-damage-7"].effects,{type = "turret-attack", turret_id = "at-cannon-turret-mk2",modifier = 0.2})
--KEEPING THE PIRAHNA TURRET UP ABOVE THE FLAME TURRET, may need balancing
table.insert(data.raw.technology["refined-flammables-3"].effects,{type = "turret-attack", turret_id = "at-acidthrower-turret",modifier = 0.6}) --3
table.insert(data.raw.technology["refined-flammables-4"].effects,{type = "turret-attack", turret_id = "at-acidthrower-turret",modifier = 0.8}) --7
table.insert(data.raw.technology["refined-flammables-5"].effects,{type = "turret-attack", turret_id = "at-acidthrower-turret",modifier = 1}) --12
table.insert(data.raw.technology["refined-flammables-6"].effects,{type = "turret-attack", turret_id = "at-acidthrower-turret",modifier = 1.2}) --18
table.insert(data.raw.technology["refined-flammables-7"].effects,{type = "turret-attack", turret_id = "at-acidthrower-turret",modifier = 0.4}) --same as flame turret
--EXPLOSIVES BASED TURRET DAMAGE BOOSTS, may need balancing
table.insert(data.raw.technology["stronger-explosives-3"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-3"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-4"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-4"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-4"].effects,{type = "turret-attack", turret_id = "at_CR_s1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-4"].effects,{type = "turret-attack", turret_id = "at_CR_s2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-5"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-5"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-5"].effects,{type = "turret-attack", turret_id = "at_CR_s1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-5"].effects,{type = "turret-attack", turret_id = "at_CR_s2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-6"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-6"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-6"].effects,{type = "turret-attack", turret_id = "at_CR_s1",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-6"].effects,{type = "turret-attack", turret_id = "at_CR_s2",modifier = 0.1})
table.insert(data.raw.technology["stronger-explosives-7"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk1",modifier = 0.2})
table.insert(data.raw.technology["stronger-explosives-7"].effects,{type = "turret-attack", turret_id = "at-rocket-turret-mk2",modifier = 0.2})
table.insert(data.raw.technology["stronger-explosives-7"].effects,{type = "turret-attack", turret_id = "at_CR_s1",modifier = 0.2})
table.insert(data.raw.technology["stronger-explosives-7"].effects,{type = "turret-attack", turret_id = "at_CR_s2",modifier = 0.2})
table.insert(data.raw.technology["stronger-explosives-7"].effects,{type = "turret-attack", turret_id = "at_A1_b",modifier = 0.2})
table.insert(data.raw.technology["stronger-explosives-7"].effects,{type = "turret-attack", turret_id = "at_A2_b",modifier = 0.2})
--PrototypeElectron Beam turret
table.insert(data.raw.technology["energy-weapons-damage-1"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.1})
table.insert(data.raw.technology["energy-weapons-damage-2"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.2})
table.insert(data.raw.technology["energy-weapons-damage-3"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.3})
table.insert(data.raw.technology["energy-weapons-damage-4"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.4})
table.insert(data.raw.technology["energy-weapons-damage-5"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.5})
table.insert(data.raw.technology["energy-weapons-damage-6"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.6})
table.insert(data.raw.technology["energy-weapons-damage-7"].effects,{type = "ammo-damage", ammo_category = "laser", modifier = 0.7})

table.insert(data.raw.technology["laser-shooting-speed-1"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.1})
table.insert(data.raw.technology["laser-shooting-speed-2"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.2})
table.insert(data.raw.technology["laser-shooting-speed-3"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.3})
table.insert(data.raw.technology["laser-shooting-speed-4"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.3})
table.insert(data.raw.technology["laser-shooting-speed-5"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.4})
table.insert(data.raw.technology["laser-shooting-speed-6"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.4})
table.insert(data.raw.technology["laser-shooting-speed-7"].effects,{type = "gun-speed", ammo_category = "laser",modifier = 0.6})

--[[attempted howitzer speed and range additions
table.insert(data.raw.technology["artillery-shell-range-1"].effects,{type = "attack_parameters.range", turret_id = "at_A1_b",modifier = 0.3})
table.insert(data.raw.technology["artillery-shell-range-1"].effects,{type = "attack_parameters.range", turret_id = "at_A2_b",modifier = 0.3})
table.insert(data.raw.technology["artillery-shell-range-1"].effects,{type = "max_distance_of_sector_revealed", turret_id = "at_A1_s1",modifier = 0.3})
table.insert(data.raw.technology["artillery-shell-range-1"].effects,{type = "max_distance_of_sector_revealed", turret_id = "at_A2_s1",modifier = 0.3})
table.insert(data.raw.technology["artillery-shell-speed-1"].effects,{type = "gun-speed", turret_id = "at_A1_b",modifier = 0.3})
table.insert(data.raw.technology["artillery-shell-speed-1"].effects,{type = "gun-speed", turret_id = "at_A2_b",modifier = 0.3})
table.insert(data.raw.technology["artillery-shell-speed-1"].effects,{type = "energy_usage", turret_id = "at_A1_s1",modifier = 0.5})
table.insert(data.raw.technology["artillery-shell-speed-1"].effects,{type = "energy_usage", turret_id = "at_A2_s1",modifier = 0.5})
]]--
