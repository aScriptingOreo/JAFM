
local power_stack_size = settings.startup["power-stack-size"].value

if power_stack_size == ("larger-stack-size") then

	for _, item in pairs(data.raw.item) do
		if string.match (item.name, "-pole") then item.stack_size = 100 end
		if string.match (item.name, "substation") then item.stack_size = 100 end
		if string.match (item.name, "steam-") then item.stack_size = 50 end
	end
	
end