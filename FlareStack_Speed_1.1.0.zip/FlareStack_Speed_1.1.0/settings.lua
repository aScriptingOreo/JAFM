data:extend({
    {
        type = "int-setting",
        name = "ptx0-flarestack-speed",
        setting_type = "startup",
        minimum_value = 1,
        maximum_value = 12000,
        default_value = 90
    }
})

