--[[
    Do all the changes in data-final-fixes.lua, in case other mods have modified the assemblers
    1. Add "input throughput" pipes on N/S plane
    2. Add "output throughput" pipes on E/W plane
]]
local function get_entity_size_in_tiles(entity)
  if entity.collision_box then
    return {math.ceil(entity.collision_box[2][1] - entity.collision_box[1][1]), math.ceil(entity.collision_box[2][2] - entity.collision_box[1][2])}
  end
end
local function get_half_entity_size(entity)
  local fullsize = get_entity_size_in_tiles(entity)
  return {fullsize[1] / 2, fullsize[2] / 2}
end

local function get_fluidbox_types(entity)
  local result = {['input'] = 0, ['output'] = 0, ['input-output'] = 0}
  if entity.fluid_boxes then
    for index, fb in ipairs(entity.fluid_boxes) do
      result[fb.production_type] = result[fb.production_type] + 1
    end
  end
  return result
end

local function process_fluidboxes(entity, entitytype)
  local entity = table.deepcopy(data.raw[entitytype][entity.name])
  if entity.fluid_boxes then
    local entity_size = get_entity_size_in_tiles(entity)
    local max_pipes_on_south_face = entity_size[1] - math.ceil((entity_size[1] - 1) / 2)
    local max_pipes_on_east_face = entity_size[2] - math.ceil((entity_size[2] - 1) / 2)
    local fluidbox_types = get_fluidbox_types(entity)
    log(entity.name .. ' ' .. serpent.block(entity_size) .. ' ' .. max_pipes_on_east_face .. ' ' .. fluidbox_types['output'] .. ' ' .. max_pipes_on_south_face .. ' ' .. fluidbox_types['input'])
    --log(serpent.block(entity.fluid_boxes))
    -- check if max number of pipes on southern and eastern faces is greater or equal to the actual number of fluid boxes
    if ((max_pipes_on_south_face >= fluidbox_types['input']) and (max_pipes_on_east_face >= fluidbox_types['output'])) then
      local half_entity_size = get_half_entity_size(entity)
      local fluid_boxes = table.deepcopy(entity.fluid_boxes)
      local i_index = 0
      local o_index = 0
      local x_offset, y_offset = 0, 0
      if (entity_size[1] % 2 == 0) then
        x_offset = 0.5
      end
      if (entity_size[2] % 2 == 0) then
        y_offset = 0.5
      end
      local first_input_fb_pos = {-((entity_size[1] % fluidbox_types['input']) + x_offset), math.ceil(half_entity_size[2]) + y_offset}
      log(entity_size[1])
      log(fluidbox_types['input'])
      log((entity_size[1] % fluidbox_types['input']))
      log('offset ' .. x_offset .. ' ' .. y_offset)
      log(first_input_fb_pos[1] .. ' ' .. first_input_fb_pos[2])
      log(first_input_fb_pos[1])
      --]]
      local first_output_fb_pos = {math.ceil(half_entity_size[1]) + x_offset, (entity_size[2] % fluidbox_types['output']) + y_offset}
      for fb_index, fb in ipairs(fluid_boxes) do -- ipairs because array with a boolean on the end
        --log(serpent.block(fluid_boxes))
        if fluidbox_types['input'] > 0 then
          if (fb.production_type == 'input') then
            fb.pipe_connections = {
              {
                position = {first_input_fb_pos[1] + (i_index * 2), first_input_fb_pos[2]},
                type = 'input-output'
              },
              {
                position = {first_input_fb_pos[1] + (i_index * 2), -first_input_fb_pos[2]},
                type = 'input-output'
              }
            }
            fb.base_level = -1
            i_index = i_index + 1
          end
        end
        if fluidbox_types['output'] > 0 then
          if fb.production_type == 'output' then
            fb.pipe_connections = {
              {
                position = {first_output_fb_pos[1], first_output_fb_pos[2] - (o_index * 2)},
                type = 'input-output'
              },
              {
                position = {-first_output_fb_pos[1], first_output_fb_pos[2] - (o_index * 2)},
                type = 'input-output'
              }
            }
            fb.base_level = 0
            o_index = o_index + 1
          end
          fb.height = 2
          fb.base_area = 0.5
        end
        --log(serpent.block(fluid_boxes))
      end
      entity.fluid_boxes = table.deepcopy(fluid_boxes)
      data:extend({entity})
      log('APP - ' .. entity.name)
    else
      log('APP - ' .. entity.name .. ' unable to adjust fluidboxes, skipping.')
    end
  end
end

for _, j in pairs(data.raw['assembling-machine']) do
  if not appmod.blacklist[j.name] then
    process_fluidboxes(j, 'assembling-machine')
  end
end

for _, j in pairs(data.raw['mining-drill']) do
  if not appmod.blacklist[j.name] then
    process_fluidboxes(j, 'mining-drill')
  end
end
