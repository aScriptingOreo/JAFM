if settings.startup["electric-furnaces-advanced"].value then
  data.raw["furnace"]["electric-furnace"].next_upgrade = "electric-furnace-2"
end