data:extend(
{
  {
    type = "item",
    name = "advanced-accumulator",
    icon = "__Advanced-Solar-and-Accumulator__/graphics/advanced-accumulator/advanced-accumulator-icon.png",
    icon_size = 32,
    subgroup = "energy",
    order = "e-b",
    place_result = "advanced-accumulator",
    stack_size = 50
  }
}
)
