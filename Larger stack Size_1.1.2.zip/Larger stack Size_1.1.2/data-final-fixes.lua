

require("prototypes.stack-size.ore-and-plate-stack-size")
require("prototypes.stack-size.utility-stack-size")
require("prototypes.stack-size.concrete-stack-size")
require("prototypes.stack-size.power-stack-size")
require("prototypes.stack-size.ammo-stack-size")
require("prototypes.stack-size.train-stack-size")
require("prototypes.stack-size.building-stack-size")
require("prototypes.stack-size.item-stack-size")

require("prototypes.stack-size.stone-brick-stack-size")
