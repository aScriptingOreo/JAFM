data:extend(
{
  {
    type = "item",
    name = "ultimate-accumulator",
    icon = "__Advanced-Solar-and-Accumulator__/graphics/ultimate-accumulator/ultimate-accumulator-icon.png",
    icon_size = 32,
    subgroup = "energy",
    order = "e-b",
    place_result = "ultimate-accumulator",
    stack_size = 50
  }
}
)
