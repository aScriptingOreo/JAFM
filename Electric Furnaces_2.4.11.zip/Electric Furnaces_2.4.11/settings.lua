data:extend({
  {
    type = "bool-setting",
    name = "electric-furnaces-stone-steel",
    setting_type = "startup",
    default_value = true,
    order = "a"
  },
  {
    type = "bool-setting",
    name = "electric-furnaces-advanced",
    setting_type = "startup",
    default_value = true,
    order = "b"
  },
  {
    type = "bool-setting",
    name = "electric-furnaces-boiler",
    setting_type = "startup",
    default_value = true,
    order = "c"
  }
})