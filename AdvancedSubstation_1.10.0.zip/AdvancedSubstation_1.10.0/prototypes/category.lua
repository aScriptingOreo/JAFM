data:extend(
{

  {
    type = "item-subgroup",
    name = "advanced-electric-poles",
    group = "logistics",
    order = "a-d"
  },
})
