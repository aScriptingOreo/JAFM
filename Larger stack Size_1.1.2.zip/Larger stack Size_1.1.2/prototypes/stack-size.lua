
data.raw.item["copper-ore"].stack_size = 200
data.raw.item["uranium-ore"].stack_size = 200
data.raw.item["iron-ore"].stack_size = 200
data.raw.item["stone"].stack_size = 200
data.raw.item["coal"].stack_size = 200

data.raw.item["solid-fuel"].stack_size = 200
data.raw.item["rocket-fuel"].stack_size = 100

data.raw.item["iron-plate"].stack_size = 200
data.raw.item["copper-plate"].stack_size = 200
data.raw.item["steel-plate"].stack_size = 200

data.raw.item["pipe"].stack_size = 200

data.raw.item["steam-engine"].stack_size = 50
data.raw.item["steam-turbine"].stack_size = 50
data.raw.item["heat-exchanger"].stack_size = 50

data.raw.item["electric-mining-drill"].stack_size = 100

data.raw.item["processing-unit"].stack_size = 200

data.raw.item["transport-belt"].stack_size = 200
data.raw.item["underground-belt"].stack_size = 100
data.raw.item["splitter"].stack_size = 100

data.raw.item["fast-transport-belt"].stack_size = 200
data.raw.item["fast-underground-belt"].stack_size = 100
data.raw.item["fast-splitter"].stack_size = 100

data.raw.item["express-transport-belt"].stack_size = 200
data.raw.item["express-underground-belt"].stack_size = 100
data.raw.item["express-splitter"].stack_size = 100

data.raw.item["wood"].stack_size = 1000
data.raw.item["copper-cable"].stack_size = 500

data.raw.item["stone-brick"].stack_size = 1000
data.raw.item["concrete"].stack_size = 1000
data.raw.item["hazard-concrete"].stack_size = 1000
data.raw.item["refined-concrete"].stack_size = 1000
data.raw.item["refined-hazard-concrete"].stack_size = 1000
data.raw.item["landfill"].stack_size = 1000

data.raw.item["low-density-structure"].stack_size = 100
data.raw.item["rocket-control-unit"].stack_size = 100

data.raw.item["plastic-bar"].stack_size = 200

data.raw["rail-planner"]["rail"].stack_size = 1000

data.raw.item["small-electric-pole"].stack_size = 100
data.raw.item["medium-electric-pole"].stack_size = 100
data.raw.item["big-electric-pole"].stack_size = 100
data.raw.item["substation"].stack_size = 100

data.raw.ammo["artillery-shell"].stack_size = 10

data.raw.item["beacon"].stack_size = 20
data.raw.item["roboport"].stack_size = 20

