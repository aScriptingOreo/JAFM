
data:extend(
{
	{
		type = "string-setting",
		name = "ore-and-plate-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-1"
	},
	{
		type = "string-setting",
		name = "utility-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-2"
	},
	{
		type = "string-setting",
		name = "power-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-3"
	},
	{
		type = "string-setting",
		name = "concrete-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-4"
	},
	{
		type = "string-setting",
		name = "stone-brick-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "200-stack-size", "larger-stack-size"},
		order = "bd-5"
	},
	{
		type = "string-setting",
		name = "ammo-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-6"
	},
	{
		type = "string-setting",
		name = "train-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-7"
	},
	{
		type = "string-setting",
		name = "building-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-8"
	},
	{
		type = "string-setting",
		name = "item-stack-size",
		setting_type = "startup",
        default_value = "larger-stack-size",
        allowed_values = {"vanilla-stack-size", "larger-stack-size"},
		order = "bd-9"
	},
}
)