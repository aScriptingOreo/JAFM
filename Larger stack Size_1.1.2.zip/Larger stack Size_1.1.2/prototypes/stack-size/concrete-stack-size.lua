
local Concrete_stack_size = settings.startup["concrete-stack-size"].value

if Concrete_stack_size == ("larger-stack-size") then

	for _, item in pairs(data.raw.item) do
		if string.match (item.name, "concrete") then item.stack_size = 1000 end
	end
	data.raw.item["landfill"].stack_size = 1000

end
