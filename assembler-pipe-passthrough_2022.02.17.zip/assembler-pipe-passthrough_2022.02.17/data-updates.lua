appmod.blacklist['escape-pod-assembler'] = true

appmod.blacklist['assembling-machine'] = not settings.startup['app_assembling_machines'].value
appmod.blacklist['assembling-machine-2'] = not settings.startup['app_assembling_machines'].value
appmod.blacklist['assembling-machine-3'] = not settings.startup['app_assembling_machines'].value

appmod.blacklist['oil-refinery'] = not settings.startup['app_oil_refineries'].value
appmod.blacklist['chemical-plant'] = not settings.startup['app_chemical_plants'].value

appmod.blacklist['pumpjack'] = not settings.startup['app_pumpjacks'].value

-- RealisticFusionReactors
appmod.blacklist['rfp-discharge-pump'] = true -- entity is 1x2, but has a calculated collision box of 2x2 2022.02.17
