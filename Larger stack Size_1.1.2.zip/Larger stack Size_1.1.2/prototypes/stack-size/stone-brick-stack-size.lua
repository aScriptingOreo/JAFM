
local Concrete_stack_size = settings.startup["stone-brick-stack-size"].value

if Concrete_stack_size == ("larger-stack-size") then

	data.raw.item["stone-brick"].stack_size = 1000

end
if Concrete_stack_size == ("200-stack-size") then

	data.raw.item["stone-brick"].stack_size = 200

end