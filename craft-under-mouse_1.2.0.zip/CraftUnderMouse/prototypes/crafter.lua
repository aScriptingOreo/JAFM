data:extend {
    {
        type = 'custom-input',
        name = 'craft-under-mouse',
        key_sequence = 'ALT + Q'
    },
    {
        type = 'custom-input',
        name = 'craft-multiple-under-mouse',
        key_sequence = 'SHIFT + ALT + Q'
    }
}