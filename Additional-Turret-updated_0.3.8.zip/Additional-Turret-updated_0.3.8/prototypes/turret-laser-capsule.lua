require ("prototypes.others")

function at_LC_base(inputs)
return
{
	layers =
	{
		{
			filename = "__Additional-Turret-updated__/graphics/entity/base.png",
			scale = 1,
			width = 224,
			height = 224,
			direction_count = 1,
			frame_count = 1,
			line_length = 1,
			axially_symmetrical = false,
			shift = { 0, 0 },
		},
	}
}
end
function blank(inputs)
return
{
	layers =
	{
		{
			filename = "__Additional-Turret-updated__/graphics/blank.png",
			priority = "medium",
			width = 1,
			height = 1,
			direction_count = 1,
			frame_count = 1,
			axially_symmetrical = false,
			shift = at_Artillery_mk2_shift,
		}
	}
}
end

function laser_copse(inputs)
return
{
	type = "container",
	name = inputs.name,
	icon = "__Additional-Turret-updated__/graphics/icon/turret-lc-icon.png",
	icon_size = 32,
	flags = {"placeable-neutral", "player-creation", "placeable-off-grid"},
	selectable_in_game = false,
	order = "b[turret]-b[laser-turret]-d[at_LC_base]",
	max_health = 500 * 1.3,
	collision_box = {{ -0.5, -0.5}, {0.5, 0.5}},
	fast_replaceable_group = "container",
	inventory_size = 0,
	picture = {
		filename = "__base__/graphics/entity/remnants/medium-remnants.png",
		priority = "extra-high",
		width = 94,
		height = 82,
		frame_count = 1,
		direction_count = 4,
		shift = {0, 0}
	},
}
end
data:extend({
{
	type = "ammo-turret",
	name = "at_LC_b",
	icon = "__Additional-Turret-updated__/graphics/icon/turret-lc-icon.png",
	icon_size = 32,
	flags = {"placeable-neutral", "placeable-player", "player-creation", "not-repairable"},
	minable = {mining_time = 1.5, result = "at_LC_b"},
	order = "b[turret]-b[laser-turret]-d[at_LC_base]",
	max_health = 2000,
	corpse = "big-remnants",
	dying_explosion = "massive-explosion",

	collision_box = {{-3.2, -3.2 }, {3.2, 3.2}},
	selection_box = {{-3.5, -3.5 }, {3.5, 3.5}},

	folding_speed = 0.04,
	inventory_size = 1,
	automated_ammo_count = 10,

	folded_animation = blank{},
	folding_animation = blank{},
	base_picture = at_LC_base{},

	vehicle_impact_sound =	{ filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },

	attack_parameters =
	{
		type = "projectile",
		ammo_category = "capsule",
		cooldown = 60 * 2,
		range = 30,
		sound =
		{
			{
				filename = "__Additional-Turret-updated__/sound/LC_turret_sound.ogg",
				volume = 1
			}
		},
	},

	call_for_help_radius = 50
},
{
	type = "logistic-container",
	name = "at_LC_i1",
	icon = "__Additional-Turret-updated__/graphics/icon/turret-lc-icon.png",
	icon_size = 32,
	flags = {"placeable-neutral", "placeable-player", "player-creation"},
	order = "b[turret]-b[laser-turret]-d[at_LC_base]",
	max_health = 300,
	corpse = "big-remnants",
	dying_explosion = "massive-explosion",
	collision_box = {{-0.5, -0.5 }, {0.5, 0.5}}, --{{-3.2, -3.2 }, {3.2, 3.2}},
	selection_box = {{-0.5, -0.5 }, {0.5, 0.5}},
	fast_replaceable_group = "container",
	inventory_size = 1,
	logistic_mode = "requester",
	logistic_slots_count = 1,
	picture = {
		filename = "__base__/graphics/entity/logistic-chest/logistic-chest-requester.png",
		priority = "extra-high",
		width = 38,
		height = 32,
		shift = {0.09375, 0}
	},
    circuit_wire_connection_point =
    {
      shadow =
      {
        red = {0.734375, 0.453125},
        green = {0.609375, 0.515625},
      },
      wire =
      {
        red = {0.40625, 0.21875},
        green = {0.40625, 0.375},
      }
    },
    circuit_wire_max_distance = 7.5,
    circuit_connector_sprites = get_circuit_connector_sprites({0.1875, 0.15625}, nil, 18),
},
laser_copse{name = "at_LC_c"}
})

LT_spot = util.table.deepcopy(data.raw["electric-turret"]["laser-turret"])
LT_spot.name = "at_LC_s"
LT_spot.icon = "__Additional-Turret-updated__/graphics/icon/turret-lc-icon.png"
LT_spot.icon_size = 32
LT_spot.flags = {"placeable-neutral", "player-creation", "placeable-off-grid"}
LT_spot.selectable_in_game = false
LT_spot.order = "b[turret]-b[laser-turret]-d[at_LC_base]"
data:extend({LT_spot})
data:extend({
{
	type = "item",
	name = "at_LC_b",
	icon = "__Additional-Turret-updated__/graphics/icon/turret-lc-icon.png",
	icon_size = 32,
	subgroup = "defensive-structure",
	order = "b[turret]-b[laser-turret]-d[at_LC_base]",
	place_result = "at_LC_b",
	stack_size = 50,
}
})


--recipe
data:extend({
{
	type = "recipe",
	name = "at_LC_b",
	enabled = false,
	energy_required = 15,
	ingredients =
	{
		{"laser-turret", 4},
		{"steel-plate", 8},
		{"pump", 2},
		{"logistic-chest-requester", 1}
	},
	result = "at_LC_b",
},
})
