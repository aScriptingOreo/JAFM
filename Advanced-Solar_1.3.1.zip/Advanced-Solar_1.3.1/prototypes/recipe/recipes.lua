data:extend(
{
  {
    type = "recipe",
    name = "advanced-accumulator",
    energy_required = 25,
    enabled = "false",
    ingredients =
    {
      {"accumulator", 5},
      {"iron-plate", 5},
      {"electronic-circuit", 2},
      {"battery", 5}
    },
    result = "advanced-accumulator"
  },
  {
    type = "recipe",
    name = "advanced-solar",
    energy_required = 25,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 10},
      {"electronic-circuit", 10},
      {"copper-plate", 10},
      {"solar-panel", 5}
    },
    result = "advanced-solar"
  },
  {
    type = "recipe",
    name = "elite-accumulator",
    energy_required = 62,
    enabled = "false",
    ingredients =
    {
      {"advanced-accumulator", 5},
      {"iron-plate", 10},
      {"advanced-circuit", 2},
      {"battery", 10}
    },
    result = "elite-accumulator"
  },
  {
    type = "recipe",
    name = "elite-solar",
    energy_required = 62,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 10},
      {"productivity-module", 1},
      {"advanced-solar", 5}
    },
    result = "elite-solar"
  }
}
)
