local water_well = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-1"])
water_well.name = "water-well-pump"
water_well.icon = "__WaterWell__/graphics/water-well-pump-icon.png"
water_well.icon_size = 32
water_well.icon_mipmaps = 1
water_well.flags = {"placeable-neutral", "placeable-player", "player-creation"}
water_well.minable = {hardness = 0.2, mining_time = 0.5, result = "water-well-pump"}
water_well.max_health = 250
water_well.corpse = "water-well-pump-remnants"
water_well.dying_explosion = "pumpjack-explosion"
water_well.resistances =
{
	{
		type = "fire",
		percent = 70
	}
}
water_well.fluid_boxes =
{
	{
		production_type = "input",
		pipe_picture = assembler2pipepictures(),
		pipe_covers = pipecoverspictures(),
		base_area = 10,
		base_level = -1,
		pipe_connections = {{ type="input", position = {0, -2} }}
	},
	{
		production_type = "output",
		pipe_picture = assembler2pipepictures(),
		pipe_covers = pipecoverspictures(),
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {0, 2} }}
	},
	off_when_no_fluid_recipe = true
}
water_well.animation =
{
	layers =
	{
		  {
			priority = "high",
			filename = "__WaterWell__/graphics/water-well-pump-anim.png",
			line_length = 8,
			width = 104,
			height = 102,
			frame_count = 40,
			shift = util.by_pixel(-4, -24),
			animation_speed = 0.5,
			hr_version =
			{
				priority = "high",
				filename = "__WaterWell__/graphics/hr-water-well-pump-anim.png",
				animation_speed = 0.5,
				scale = 0.5,
				line_length = 8,
				width = 206,
				height = 202,
				frame_count = 40,
				shift = util.by_pixel(-4, -24)
			}
		  },
		  {
			priority = "high",
			filename = "__WaterWell__/graphics/water-well-pump-anim-shadow.png",
			animation_speed = 0.5,
			draw_as_shadow = true,
			line_length = 8,
			width = 155,
			height = 41,
			frame_count = 40,
			shift = util.by_pixel(17.5, 14.5),
			hr_version =
			{
				priority = "high",
				filename = "__WaterWell__/graphics/hr-water-well-pump-anim-shadow.png",
				animation_speed = 0.5,
				draw_as_shadow = true,
				line_length = 8,
				width = 309,
				height = 82,
				frame_count = 40,
				scale = 0.5,
				shift = util.by_pixel(17.75, 14.5)
			}
		  }
	}
}
water_well.working_sound =
{
	sound = { filename = "__base__/sound/pumpjack.ogg" },
	apparent_volume = 1.5,
}
water_well.crafting_categories = {"water-well-production"}
water_well.crafting_speed = 1.0
water_well.energy_source =
{
	type = "electric",
	usage_priority = "secondary-input",
	emissions = 0.1
}
water_well.energy_usage = "100kW"
water_well.ingredient_count = 2
water_well.module_specification =
{
	module_slots = 2
}
water_well.fixed_recipe = "water-well-flow"
water_well.allowed_effects = {"consumption", "speed", "productivity", "pollution"}
water_well.next_upgrade = nil

data:extend(
{
	water_well,
	{
		type = "corpse",
		name = "water-well-pump-remnants",
		icon = "__WaterWell__/graphics/water-well-pump-icon.png",
		icon_size = 32,
		icon_mipmaps = 1,
		flags = {"placeable-neutral", "placeable-player", "player-creation"},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
		tile_width = 3,
		tile_height = 3,
		selectable_in_game = false,
		subgroup = "remnants",
		order = "d[remnants]-a[generic]-b[medium]",
		time_before_removed = 60 * 60 * 15, -- 15 minutes
		final_render_layer = "remnants",
		remove_on_tile_placement = false,
		animation = 
		make_rotated_animation_variations_from_sheet(
			2,
			{
				filename = "__WaterWell__/graphics/remnants/pumpjack-remnants.png",
				line_length = 1,
				width = 138,
				height = 142,
				frame_count = 1,
				direction_count = 1,
				shift = util.by_pixel(0, 3),
				hr_version =
				{
					filename = "__WaterWell__/graphics/remnants/hr-pumpjack-remnants.png",
					line_length = 1,
					width = 274,
					height = 284,
					frame_count = 1,
					direction_count = 1,
					shift = util.by_pixel(0, 3.5),
					scale = 0.5,
				}
			}
		)
	}
})