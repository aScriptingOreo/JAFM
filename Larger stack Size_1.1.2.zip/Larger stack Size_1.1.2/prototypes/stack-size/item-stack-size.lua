
local item_stack_size = settings.startup["item-stack-size"].value

if item_stack_size == ("larger-stack-size") then

	data.raw.item["wood"].stack_size = 1000
	
	data.raw.item["plastic-bar"].stack_size = 200
	data.raw.item["low-density-structure"].stack_size = 100
	data.raw.item["rocket-control-unit"].stack_size = 100
	data.raw.item["processing-unit"].stack_size = 200
	
	data.raw.item["solid-fuel"].stack_size = 200
	data.raw.item["rocket-fuel"].stack_size = 100
end